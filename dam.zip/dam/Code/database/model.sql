-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2020 at 09:06 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `model`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `CAL`()
    NO SQL
update control
 set reserved=(inflow)-(outflow)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(10) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `username`, `password`) VALUES
(1, 'Tony', 'tony@12.in', 'admin', 'admin'),
(2, 'Rahul', 'rahul@14.in', 'rahul', 'rahul'),
(3, 'King', 'king@191.in', 'king', 'king');

-- --------------------------------------------------------

--
-- Table structure for table `control`
--

CREATE TABLE IF NOT EXISTS `control` (
  `type` varchar(40) DEFAULT NULL,
  `name` varchar(40) NOT NULL,
  `inflow` int(30) NOT NULL,
  `outflow` int(30) NOT NULL,
  `reserved` int(30) NOT NULL,
  `electricity` varchar(40) DEFAULT NULL,
  `Description` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `control`
--

INSERT INTO `control` (`type`, `name`, `inflow`, `outflow`, `reserved`, `electricity`, `Description`) VALUES
('Large', 'iduki', 20000, 5000, 15000, '1233w', 'GOOD'),
('Large', 'Krishna', 1230000, 2000, 1228000, '1233w', 'nice'),
('Large', 'KRS', 1230000, 30000, 1200000, '1200w', 'NICE'),
('Large', 'Sagara', 14200, 200, 14000, '541Watt', 'Strong'),
('Large', 'tunga', 12000, 2000, 10000, '1200000w', 'Nice');

-- --------------------------------------------------------

--
-- Table structure for table `dams`
--

CREATE TABLE IF NOT EXISTS `dams` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `year` date NOT NULL,
  `type` varchar(40) DEFAULT NULL,
  `capacity` varchar(35) NOT NULL,
  `place` varchar(40) DEFAULT NULL,
  `built` varchar(55) NOT NULL,
  `file` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dams`
--

INSERT INTO `dams` (`id`, `name`, `year`, `type`, `capacity`, `place`, `built`, `file`) VALUES
(2, 'iduki', '2019-11-04', 'Large', '12900TMC', 'CMY', 'Sri. C.V Mathews ', 'your_site_name_9972bc1db22dd650d4dc0cabd5b696c0.jpg'),
(4, 'Krishna', '2019-10-27', 'Large', '12400TMC', 'CMY', '  Sir M. Visvesvaraya ', 'your_site_name_9972bc1db22dd650d4dc0cabd5b696c0.jpg'),
(12, 'KRS', '2019-10-27', 'Large ', '1200TMC', 'mysore', ' Sir M. Visvesvaraya', 'your_site_name_9972bc1db22dd650d4dc0cabd5b696c0.jpg'),
(6, 'Nagasagar', '2020-05-22', 'Large', '12400TMC', 'andhra pradesh', 'Civil Engg', 'your_site_name_492d02cec61488b23cfe6f8f18a009fb.jpg'),
(1, 'Sagara', '2020-05-06', 'Large', '12400TMC', 'andhra pradesh', 'Rahul', 'your_site_name_305b97888f0b151c1a8305d901d86bfd.jpg'),
(3, 'tunga', '2019-11-05', 'Large', '4000TMC', 'Karnataka', ' Dr. Thirumalai Iyengar', 'your_site_name_548f3f37d48ffa25522c91fc56825b82.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `id` int(10) NOT NULL,
  `name` varchar(45) NOT NULL,
  `dno` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `name`, `dno`) VALUES
(4, 'delhi', 5),
(5, 'Karnataka', 5),
(1, 'kolkata', 3),
(2, 'Tamil nadu', 3),
(3, 'Kerala', 5);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(11) NOT NULL,
  `name` varchar(55) NOT NULL,
  `number` int(12) NOT NULL,
  `username` varchar(55) NOT NULL,
  `password` varchar(55) NOT NULL,
  `file` varchar(400) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `number`, `username`, `password`, `file`) VALUES
(1, 'Tony', 984657231, 'tony', 'tony', 'your_site_name_a25e20df04b85b1c8d52066b330000d5.jpg'),
(6, 'Rahul', 987654321, 'rahul', 'rahul', 'your_site_name_a25e20df04b85b1c8d52066b330000d5.jpg'),
(7, 'King', 987654320, 'king', 'king', 'your_site_name_1729021c31896ec2e8cd5859b65e032e.jpg'),
(8, 'King', 2147483647, 'king', 'king', '');

-- --------------------------------------------------------

--
-- Table structure for table `waterstatus`
--

CREATE TABLE IF NOT EXISTS `waterstatus` (
  `name` varchar(40) NOT NULL,
  `inflow` int(30) NOT NULL,
  `outflow` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `waterstatus`
--

INSERT INTO `waterstatus` (`name`, `inflow`, `outflow`) VALUES
('', 1230000, 2000),
('', 1230000, 123),
('', 20000, 5000),
('', 1230000, 30000),
('', 1200, 200),
('Krishna', 1230000, 2000),
('tunga', 1230000, 30000),
('tunga', 1230000, 30000),
('tunga', 12000, 2000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `control`
--
ALTER TABLE `control`
 ADD PRIMARY KEY (`name`), ADD UNIQUE KEY `name_2` (`name`), ADD UNIQUE KEY `reserved` (`reserved`), ADD FULLTEXT KEY `name` (`name`);

--
-- Indexes for table `dams`
--
ALTER TABLE `dams`
 ADD PRIMARY KEY (`name`), ADD UNIQUE KEY `name_2` (`name`), ADD KEY `name` (`name`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `control`
--
ALTER TABLE `control`
ADD CONSTRAINT `control_ibfk_1` FOREIGN KEY (`name`) REFERENCES `dams` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
