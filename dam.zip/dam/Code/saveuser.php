<?php
session_start();
include('connect.php');
//$a = $_POST['id'];
$k = $_POST['name'];
//$e = $_POST['email'];
$b = $_POST['number'];
$c = $_POST['username'];
$d = $_POST['password'];
// query



  //do your write to the database filename and other details   
$sql = "INSERT INTO user (name,number,username,password) VALUES (:k,:b,:c,:d)";
$q = $db->prepare($sql);
$q->execute(array(':k'=>$k,':b'=>$b,':c'=>$c,':d'=>$d));
header("location: user.php");

	
?>